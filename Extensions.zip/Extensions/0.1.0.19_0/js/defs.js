var source_ = "919919";
var uqid_ = "919919chrome";